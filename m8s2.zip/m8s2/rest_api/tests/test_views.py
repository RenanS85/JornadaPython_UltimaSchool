from datetime import date

import pytest

from rest_framework.test import APIClient

from reservation.models import *

@pytest.fixture
def pet_shop():
    pet_shop = PetShop.objects.create(
        name = "test_petshop",
        street = "test_street",
        number = "test_number",
        neighborhood = "test_neighborhood"
    )

    return pet_shop

@pytest.fixture
def category():
    pet_category = PetCategory.objects.create(
        pet_category = "cachorro")
    
    return pet_category

@pytest.mark.django_db
def test_pet_shop_status_code_get():
    client = APIClient()
    response = client.get("/api/petshop")
    assert response.status_code == 200

@pytest.mark.django_db
def test_pet_shop_status_code_invalid_get():
    client = APIClient()
    response = client.get("/ap/pet")
    assert response.status_code == 404

@pytest.mark.django_db
def test_todos_pet_shops():
    client = APIClient()
    response = client.get("/api/petshop")
    assert len(response.data["results"]) == 0

@pytest.mark.django_db
def post_agendamento():
    pet_shop = PetShop.objects.create(
        name = "test_petshop",
        street = "test_street",
        number = "test_number",
        neighborhood = "test_neighborhood"
    )

    pet_category = PetCategory.objects.create(
        pet_category = "cachorro")
    
    reservation = {
        "name": "test_name",
        "email": "test@email.com",
        "pet_category": pet_category.id,
        "pet_name": "pet_test",
        "date": "2022-11-11",
        "shift": "manhã",
        "size":1,
        "observation": "test_observation",
        "petshop": pet_shop.id}

    client = APIClient()
    response = client.post("/api/reservation", reservation)
    assert response.satus_code == 200

@pytest.mark.django_db
def update_agendamento():
    pet_shop = PetShop.objects.create(
        name = "test_petshop",
        street = "test_street",
        number = "test_number",
        neighborhood = "test_neighborhood"
    )

    pet_category = PetCategory.objects.create(
        pet_category = "cachorro")
    
    reservation = {
        "name": "test_name",
        "email": "test@email.com",
        "pet_category": pet_category.id,
        "pet_name": "pet_test",
        "date": "2022-11-11",
        "shift": "manhã",
        "size":1,
        "observation": "test_observation",
        "petshop": pet_shop.id}

    client = APIClient()
    response = client.post("/api/reservation", reservation)
    reservation["date"] = "teste_put_name" #aualizando o valor nome
    response = client.put(f"/api/reservation/{reservation.id}",reservation)
    assert response.satus_code == 200

@pytest.mark.django_db
def post_agendamento():
    pet_shop = PetShop.objects.create(
        name = "test_petshop",
        street = "test_street",
        number = "test_number",
        neighborhood = "test_neighborhood"
    )

    pet_category = PetCategory.objects.create(
        pet_category = "cachorro")
    
    reservation = {
        "name": "test_name",
        "email": "test@email.com",
        "pet_category": pet_category.id,
        "pet_name": "pet_test",
        "date": "2022-11-11",
        "shift": "manhã",
        "size":1,
        "observation": "test_observation",
        "petshop": pet_shop.id}

    client = APIClient()
    response = client.delete("/api/reservation", reservation)
    assert response.satus_code == 200

    
@pytest.mark.django_db
def test_captura_agendamento():
    client = APIClient()
    response = client.get("/api/reservation_by_category")
    assert response.status_code == 200