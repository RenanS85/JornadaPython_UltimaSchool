from django.contrib.auth.models import User
from django.core.management.base import BaseCommand

from rest_framework.authtoken.models import Token

class Command(BaseCommand):
    help = 'cria no token para ser usado'

    def add_arguments(self, parser):
        parser.add_argument('--username', required=True)
        parser.add_argument('--password', required=True)

    def handle(self, *args, **options):
        username = options['username']
        password = options['password']

        self.stdout.write(
            self.style.WARNING(f'criando usuario com nome {username}')
        )

        user = User(username = username)
        user.first_name = username
        user.set_password(password)
        user.save()

        self.stdout.write(
            self.style.SUCCESS('usuario criado')
        )

        self.stdout.write(
            self.style.WARNING('criando token')
        )

        token = Token.objects.create(user=user)

        self.stdout.write(
            self.style.SUCCESS(f'token criado para usuario: {token.key}')
        )

        # token criado para usuario: d2367c1a9c8118dab864ad3453fb3275b84617b4

