from .test_models import reservation
from datetime import date, timedelta
import pytest
from pytest_django.asserts import assertTemplateUsed
from reservation.models import Reservation

@pytest.fixture
def reservation():
    pet_shop = {
        "name" :"test_petshop",
        "street" : "test_street",
        "number" : "test_number",
        "neighborhood" : "test_neighborhood"
    }

    pet_category = {
        "pet_category" : "cachorro"
    }

    tomorrow = date.today() + timedelta(days=1)
    
    reservation = {
        "name": "test_name",
        "email": "test@email.com",
        "pet_category": pet_category,
        "pet_name": "pet_test",
        "date": tomorrow,
        "shift":"manhã",
        "size": 1,
        "observation": "test_observation",
        "petshop": pet_shop }

    return reservation

@pytest.fixture
def invalid_field_type_reservation():
  

    pet_category = {
        "pet_category" : "cachorro"
    }

    tomorrow = date.today() + timedelta(days=1)
    
    reservation = {
        "name": "",
        "email": 1,
        "pet_category": pet_category,
        "pet_name": "pet_test",
        "date": -1,
        "shift":"manhã",
        "size": 1,
        "observation": "test_observation",}

    return reservation


@pytest.mark.django_db
def test_reserva_view_deve_retornar_template(client):
    response = client.get("/make_reservation/")

    assert response.status_code == 200
    assertTemplateUsed("make_reservation.html")

@pytest.mark.django_db
def test_reserva_view_deve_retornar_sucesso(client, reservation):
    data = reservation

    response = client.post("/make_reservation/")
    assert response.status_code == 200

'''@pytest.mark.django_db
def test_reserva_view_deve_criar_reserva(client, reservation):
 
    client.post("/make_reservation/", reservation)

    assert Reservation.objects.all().count() == 1'''

@pytest.mark.django_db
def test_reserva_view_deve_retornar_404(client):

    response = client.get("/invalid_url/")
    assert response.status_code == 404




    

 