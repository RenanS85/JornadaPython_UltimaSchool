import pytest
import datetime 

from reservation.models import Reservation, PetCategory, PetShop


@pytest.fixture
def reservation():
    pet_shop = PetShop.objects.create(
        name = "test_petshop",
        street = "test_street",
        number = "test_number",
        neighborhood = "test_neighborhood"
    )

    pet_category = PetCategory.objects.create(
        pet_category = "cachorro")
    
    reservation = Reservation.objects.create(
        name = "test_name",
        email = "test@email.com",
        pet_category = pet_category,
        pet_name = "pet_test",
        date = datetime.date(2022,8,30),
        shift = "manhã",
        size = 1,
        observation = "test_observation",
        petshop = pet_shop)
    return reservation

@pytest.mark.django_db
def test_str_reserva_deve_retornar_string_formatada(reservation):
     
    assert str(reservation.name) == "test_name"

@pytest.mark.django_db
def test_pet_shop_reservation_count(reservation):
    pet_shop = reservation.petshop

    assert pet_shop.reservations_count() == 1
   



    




    

