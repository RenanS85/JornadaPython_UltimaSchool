from django.contrib import admin
from reservation.models import Reservation

@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = ["name", "email", "pet_name", "date", "shift"]
    search_fields = ["name", "email", "pet_name"]
    list_filter = ["date", "shift", "size"]