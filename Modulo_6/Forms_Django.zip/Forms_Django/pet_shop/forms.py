from  django import forms

class ContactForm(forms.Form):
    name = forms.CharField(max_length=255)
    email = forms.EmailField()
    message = forms.CharField(widget=forms.Textarea)

class ScheduleForm(forms.Form):
    pet_name = forms.CharField(max_length=255)
    phone = forms.CharField()
    reservation_day = forms.DateField()
    observation = forms.CharField(widget=forms.Textarea)

    