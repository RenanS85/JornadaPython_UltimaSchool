from django.shortcuts import render
from pet_shop.forms import ContactForm, ScheduleForm

def index(request):
    return render(request, 'index/index.html')

def contact(request):
    nice=False
    if request.method == "GET":
        form = ContactForm()
    else:
        form = ContactForm(request.POST)
        if form.is_valid():
            nice = True
    context = {"name": "Renan",
            "number": "(19) 9 1111-2222", 
            "form": ContactForm(request.POST),
            "nice": nice}
    return render(request, 'contact/contact.html', context )

def schedule(request):
    nice = False
    if request.method == "GET":
        form = ScheduleForm()
    else:
        form = ScheduleForm(request.POST)
        if form.is_valid():
            nice = True
    context = {"form": ScheduleForm(request.POST),
               "nice": nice}
    return render(request, 'schedule/schedule.html', context)
