from distutils.text_file import TextFile
from django.db import models

class Contact(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField(max_length=75)
    message = models.TextField()
    date = models.DateField(auto_now_add=True)

class Schedule(models.Model):
    pet_name = models.CharField(max_length=255)
    phone = models.CharField(max_length=55)
    reservation_day = models.DateField()
    observation = models.TextField()
    
