from django.apps import AppConfig


class PetShopConfig(AppConfig):
    verbose_name = "Módulo Geral"
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pet_shop'
