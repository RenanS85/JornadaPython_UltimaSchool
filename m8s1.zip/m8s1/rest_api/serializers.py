from rest_framework import serializers
from rest_framework.serializers import PrimaryKeyRelatedField

from reservation.models import Reservation, PetShop, PetCategory



class PetShopSerializer(serializers.ModelSerializer):
    reservation = serializers.HyperlinkedRelatedField(
        many = True,
        read_only = True,
        view_name='api:reservation-detail'
    )

    class Meta:
        model = PetShop
        fields = '__all__'


class PetShopRelatedFieldCustomSerializer(PrimaryKeyRelatedField):

    def __init__(self, **kwargs):
        self.seralizer = PetShopSerializer
        super().__init__(**kwargs)

    def use_pk_only_optimization(self):
        return False

    def to_representation(self, value):
        return self.seralizer(value, context=self.context).data


class ReservationSerializer(serializers.ModelSerializer):
    petshop = PetShopRelatedFieldCustomSerializer(
        queryset = PetShop.objects.all(),
        read_only = False
    )

    class Meta:
        model = Reservation
        fields = '__all__'


class ReservationsByShiftSerializer(serializers.ModelSerializer):
    turno = serializers.SerializerMethodField()

    class Meta:
        model = Reservation
        fields = ['turno']


    def get_turno(self,obj):

        if obj.shift in 'Manhã':

            return f'Manhã : {obj.name}'

        return f'Tarde : {obj.name}'


class ReservationPetNameSerializer(serializers.ModelSerializer):

    class Meta:
        model = Reservation
        fields = ["id", "name" ,"pet_name"]

class ReservationByPetCategorySizeSerializer(serializers.ModelSerializer):
    reservation=ReservationPetNameSerializer(many=True)

    class Meta:
        model = PetCategory
        fields = ["pet_category","reservation"]