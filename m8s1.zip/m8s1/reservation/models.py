from django.db import models

class Reservation(models.Model):
    
    SIZE_OPTIONS = [
        (1,"Pequeno"),
        (2, "Médio"),
        (3,"Grande")
    ]

    SHIFT_OPTIONS = [
        ("Manhã", "manhã"),
        ("Tarde", "tarde")
    ]

    name = models.CharField(verbose_name="Nome", max_length=70)
    email = models.EmailField(verbose_name="E-mail", max_length=70)
    pet_category = models.ForeignKey(
        "PetCategory",
        related_name="reservation", 
        blank=True, 
        null=True, 
        on_delete=models.CASCADE)
    pet_name = models.CharField(verbose_name="Nome do Pet", max_length=70)
    date = models.DateField(verbose_name="Date", help_text="dd/mm/aaaa", max_length=10)
    shift = models.CharField(verbose_name="Turno", max_length=10, choices=SHIFT_OPTIONS)
    size = models.IntegerField(verbose_name="Tamanho do Pet", choices=SIZE_OPTIONS)
    observation = models.TextField(blank=True)
    petshop = models.ForeignKey(
        "Petshop", 
        blank=True,
        null=True,
        related_name="reservation",
        on_delete=models.CASCADE
        )

    def __str__(self):
        return f"{self.name}: {self.date} - {self.shift}"

    class Meta:
        verbose_name = "Reserva de banho"
        verbose_name_plural = "Reservas de banho"

class PetShop(models.Model):
    name = models.CharField(verbose_name="Nome", max_length=70)
    street = models.CharField(verbose_name="Rua", max_length=70)
    number = models.CharField(verbose_name="Numero", max_length=70)
    neighborhood = models.CharField(verbose_name="Bairro", max_length=70)

    def reservations_count(self):
        return self.reservation.count()


class PetCategory(models.Model):

    PET_CATEGORY_OPTIONS = [
        ("cachorro", "cachorro"),
        ("gato","gato"),
        ("coelho","coelho")
            ]

    pet_category = models.CharField(verbose_name="categoria do pet", max_length=20, choices=PET_CATEGORY_OPTIONS)
