from django.contrib import admin
from pet_shop.models import Contact
from django.contrib import messages

@admin.action(description= "Marcar Formulário(s) de contato como lido(s)")
def set_as_read(modeladmin, request, queryset):
    queryset.update(read=True)
    modeladmin.message_user(request, "Formulário(s) marcado(s) como lido(s)", messages.SUCCESS)

@admin.register(Contact)
class ContatoAdmin(admin.ModelAdmin):
    list_display = ["name", "email", "date","read"]
    search_fields = ["name", "email"]
    list_filter = ["date"]
    actions = [set_as_read]
