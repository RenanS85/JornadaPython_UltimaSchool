from django.shortcuts import render
from reservation.forms import ReservationForm

def make_reservation(request):
    form = ReservationForm(request.POST or None)
    nice = False
    if form.is_valid():
        form.save()
        nice = True
    context = {"form" : form ,
               "nice": nice}
    return render(request, 'make_reservation/make_reservation.html', context=context)