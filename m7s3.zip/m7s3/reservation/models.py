from django.db import models

class Reservation(models.Model):
    
    SIZE_OPTIONS = [
        (1,"Pequeno"),
        (2, "Médio"),
        (3,"Grande")
    ]

    SHIFT_OPTIONS = [
        ("Manhã", "manhã"),
        ("Tarde", "tarde")
    ]

    name = models.CharField(verbose_name="Nome", max_length=70)
    email = models.EmailField(verbose_name="E-mail", max_length=70)
    pet_name = models.CharField(verbose_name="Nome do Pet", max_length=70)
    date = models.DateField(verbose_name="Date", help_text="dd/mm/aaaa", max_length=10)
    shift = models.CharField(verbose_name="Turno", max_length=10, choices=SHIFT_OPTIONS)
    size = models.IntegerField(verbose_name="Tamanho do Pet", choices=SIZE_OPTIONS)
    observation = models.TextField(blank=True)

    def __str__(self):
        return f"{self.name}: {self.date} - {self.shift}"

    class Meta:
        verbose_name = "Reserva de banho"
        verbose_name_plural = "Reservas de banho"


