from django.urls import path    

from rest_api.views import get_reservation_clients, PetReservation, ReservationsByShift
from rest_framework.routers import SimpleRouter

app_name = 'rest_api'

router = SimpleRouter(trailing_slash=False)

urlpatterns = [
    path(   
        'reservation_clients', get_reservation_clients, 
        name='reservation_clientes_api'),
    path(   
        'reservation_by_shift', ReservationsByShift.as_view(), 
        name='reservation_by_shift')
    
    ]

router.register("reservation", PetReservation)

urlpatterns+=router.urls