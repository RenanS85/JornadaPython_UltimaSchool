from rest_framework import serializers

from reservation.models import Reservation

class ReservationSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Reservation
        fields = '__all__'

class ReservationsByShiftSerializer(serializers.ModelSerializer):
    turno = serializers.SerializerMethodField()

    class Meta:
        model = Reservation
        fields = ['turno']


    def get_turno(self,obj):

        if obj.shift in 'Manhã':

         return f'Manhã : {obj.name}'

        return f'Tarde : {obj.name}'
        