from django.shortcuts import render

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.viewsets import ModelViewSet, generics

from reservation.models import Reservation
from rest_api. serializers import ReservationSerializer, ReservationsByShiftSerializer

class PetReservation(ModelViewSet):
    queryset = Reservation.objects.all()
    serializer_class = ReservationSerializer

class ReservationsByShift(generics.ListAPIView):

    queryset = Reservation.objects.all()
    serializer_class = ReservationsByShiftSerializer



@api_view(['GET'])
def get_reservation_clients(request):
    if request.method == "GET":
        all_reservations= Reservation.objects.all()
        reservation_list = []
        for reservation in all_reservations:
            reservation_list.append(
            {
                "name": reservation.name, 
                "email": reservation.email, 
                "pet_name": reservation.pet_name, "date": reservation.date,
                "shift": reservation.shift,
                "pet_size": reservation.size,
                "observation": reservation.observation
            })
        return Response({"Reservations": reservation_list})
    
    


    
    