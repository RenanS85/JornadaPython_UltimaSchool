from django.shortcuts import render
from pet_shop.forms import ContactForm, ScheduleForm

def index(request):
    return render(request, 'index/index.html')

def contact(request):
    nice=False
    form = ContactForm(request.POST or None)
    if form.is_valid():
        nice = True
        form.save()
    context = {"name": "Renan",
            "number": "(19) 9 1111-2222", 
            "form": form,
            "nice": nice}
    return render(request, 'contact/contact.html', context )

def schedule(request):
    nice = False
    form = ScheduleForm(request.POST or None)
    if form.is_valid():
        nice = True
        form.save()
    context = {"form": form,
               "nice": nice}
    return render(request, 'schedule/schedule.html', context)
