from distutils.text_file import TextFile
from tabnanny import verbose
from django.db import models

class Contact(models.Model):
    name = models.CharField(verbose_name="Nome", max_length=255)
    email = models.EmailField(verbose_name="E-mail", max_length=75)
    message = models.TextField(verbose_name="mensagem")
    date = models.DateField(verbose_name="Data-envio", auto_now_add=True)
    read = models.BooleanField(verbose_name="Lido", default=False, blank=True)
    def __str__(self):
        return f'nome: {self.name} email: {self.email}'
    class Meta:
        verbose_name = "Formulário de Contato"
        verbose_name_plural = "Formulário de Contatos"
        ordering = ['-date']

class Schedule(models.Model):
    pet_name = models.CharField(max_length=255)
    phone = models.CharField(max_length=55)
    reservation_day = models.DateField()
    observation = models.TextField()
    
