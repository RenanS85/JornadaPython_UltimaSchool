from  django import forms
from pet_shop.models import Contact, Schedule

class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = ["name", "email", "message"]
    
class ScheduleForm(forms.ModelForm):
   class Meta:
        model = Schedule
        fields = ["pet_name", "phone", "reservation_day", "observation"]

    