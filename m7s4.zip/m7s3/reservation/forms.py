from django import forms
from reservation.models import Reservation
from datetime import date

class ReservationForm(forms.ModelForm):

    def clean_date(self):
        form_date = self.cleaned_data["date"]
        today_date = date.today()
        if form_date < today_date:
            raise forms.ValidationError('OPS, a data informada é anterior a data de hoje')
        return form_date

    def clean_shift(self):
        form_date = self.cleaned_data["date"]
        form_shift = self.cleaned_data["shift"]
        baths_in_same_day_and_hour = Reservation.objects.filter(date=form_date, shift=form_shift).count()
        if baths_in_same_day_and_hour >= 4:
            raise forms.ValidationError(f'Ops esse horário já esta lotado, para o turno da {form_shift}')
        return form_shift
        
    class Meta:
        model = Reservation
        fields = "__all__"