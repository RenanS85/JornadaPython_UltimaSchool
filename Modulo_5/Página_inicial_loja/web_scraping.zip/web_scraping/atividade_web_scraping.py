from requests_html import HTMLSession
import sqlite3


url = "https://raspagem.herokuapp.com/noticias/"
session = HTMLSession()
response = session.get(url)
links = response.html.find("a.nav-link")
news_list = []
for link in links:
    if link.attrs['href'] != '/noticias/':
        url = f"https://raspagem.herokuapp.com{link.attrs['href']}"
        response = session.get(url)
        titles = response.html.find("h3.mb-0")
        datas = response.html.find("div.mb-1")
        descriptions = response.html.find("p.card-text")
        for title in titles:
            dic = {}
            dic['title'] = title.text
        for data in datas:
            dic['data'] = data.text
        for description in descriptions:
            dic['description'] = description.text
        news_list.append(dic)  

try:
    conn = sqlite3.connect('scraping.db')
    cur = conn.cursor()
except:
    print('algo deu errado')
else:
    for each_news in news_list:
        cur.execute(f'''
        insert into scraping values (
            null,
            "{each_news['title']}",
            "{each_news['data']}",
            "{each_news['description']}"
        );
        ''')
    conn.commit()
    conn.close()
    










        

